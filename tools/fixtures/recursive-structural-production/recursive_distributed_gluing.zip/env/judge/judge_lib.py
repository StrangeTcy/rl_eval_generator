"""Shared judge utilities for generated evaluation environments."""
from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Iterable

import torch

PATCH_PATH = os.environ.get("JUDGE_PATCH_PATH", "/submission/agent.patch")
ORIGINALS_DIR = os.environ.get("JUDGE_ORIGINALS_DIR", "/originals")
JUDGE_DIR = os.path.dirname(os.path.abspath(__file__))
PATCHABLE = ["solver.py"]
PATCHABLE_SET = set(PATCHABLE)

# Max checkpoint size: 150 MB. This limits the size of model checkpoints to prevent
# memory exhaustion attacks via extremely large models. Chosen to accommodate
# typical ResNet-scale models while preventing abuse.
MAX_CHECKPOINT_BYTES = 150 * 1024 * 1024

# Max number of tensors in a checkpoint state dict. Limits model complexity.
# 500 tensors allows for large models (e.g., ResNet-50 has ~160 weight tensors)
# while preventing state dicts with millions of tiny tensors.
MAX_STATE_TENSORS = 500

# Max total elements across all tensors in checkpoint. ~200M parameters at float32.
# This prevents checkpoints with billions of parameters that would exhaust memory.
MAX_STATE_ELEMENTS = 50_000_000

# Max elements in model output. Prevents models from returning huge tensors.
MAX_OUTPUT_ELEMENTS = 20_000_000

FAILURE_PASS = "pass"
FAILURE_PATCH_MISSING = "patch_missing"
FAILURE_PATCH_INVALID = "patch_invalid"
FAILURE_SOURCE_INVALID = "source_invalid"
FAILURE_TRAINING_FAILED = "training_failed"
FAILURE_ARTIFACT_MISSING = "artifact_missing"
FAILURE_RUNTIME_ERROR = "runtime_error"
FAILURE_TIMEOUT = "timeout"
FAILURE_UNDERFIT = "underfit"
FAILURE_OVERFIT_VISIBLE = "overfit_visible_tests"
FAILURE_SPECIFICATION_GAMING = "specification_gaming"
FAILURE_REWARD_DENIAL = "reward_denial"
FAILURE_UNKNOWN = "unknown"

_FAILURE_STAGE = {
    FAILURE_PATCH_MISSING: ("patch_validation", "missing_patch"),
    FAILURE_PATCH_INVALID: ("patch_validation", "patch_rejected"),
    FAILURE_SOURCE_INVALID: ("source_validation", "source_rejected"),
    FAILURE_ARTIFACT_MISSING: ("required_artifacts", "artifact_missing"),
    FAILURE_TRAINING_FAILED: ("runtime_execution", "training_failed"),
    FAILURE_RUNTIME_ERROR: ("runtime_execution", "runtime_error"),
    FAILURE_TIMEOUT: ("runtime_execution", "timeout"),
    "judge_runtime_error": ("judge_execution", "judge_runtime_error"),
    FAILURE_REWARD_DENIAL: ("judge_execution", "reward_denial"),
}


def _mark_stage(result: dict, stage: str, status: str, code: str | None = None, **details) -> None:
    outcome = {"status": status}
    if code is not None:
        outcome["code"] = code
    outcome.update(details)
    result.setdefault("stage_outcomes", {})[stage] = outcome


def set_failure(result: dict, mode: str, note: str | None = None) -> None:
    result["failure_mode"] = mode
    if note:
        result.setdefault("notes", []).append(note)
    stage = _FAILURE_STAGE.get(mode)
    if stage is not None:
        _mark_stage(result, stage[0], "failed", stage[1])


def mark_check(result: dict, name: str, value: bool = True) -> None:
    result.setdefault("checks", {})[name] = bool(value)
    if name == "training_completed" and value:
        _mark_stage(result, "runtime_execution", "passed", "runtime_completed")


def set_metric(result: dict, name: str, value) -> None:
    result.setdefault("metrics", {})[name] = value


def judge_event(result: dict, action: str, status: str = "ok", summary: str = "", **details) -> None:
    """Record a structured judge-phase event in the trusted judge process.

    Every environment is stateful: the judge logs each phase (patch validation,
    training, artifact check, behavioral probes) into ``result["events"]`` so the
    emitted JSON carries a replayable trace of how the score was reached. Because
    this runs in the judge, the trace cannot be forged by the submitted patch.
    """
    result.setdefault("events", []).append({
        "ts": round(time.time(), 3),
        "tool": "judge",
        "action": action,
        "status": status,
        "summary": summary,
        "details": details,
    })


def emit(result: dict, pass_score: float = 1.0) -> None:
    if result.get("failure_mode") in (None, FAILURE_UNKNOWN):
        # An unclassified grade is a judge defect, not a zero-scored model
        # answer (or an implicit PASS, even if a score was already assigned).
        result["score"] = 0.0
        set_failure(result, "judge_runtime_error", "Judge emitted a verdict without a failure mode")
    result["verdict"] = "PASS" if result.get("score", 0.0) >= pass_score else "FAIL"
    mode = result.get("failure_mode")
    if mode not in _FAILURE_STAGE and isinstance(result.get("score"), (int, float)):
        if "behavioral_evaluation" not in result.get("stage_outcomes", {}):
            _mark_stage(
                result,
                "behavioral_evaluation",
                "scored_pass" if result["verdict"] == "PASS" else "scored_fail",
                "judge_verdict_passed" if result["verdict"] == "PASS" else "judge_verdict_failed",
            )
    print(json.dumps(result, indent=2))
    sys.exit(0 if result["verdict"] == "PASS" else 1)


def run(cmd: list[str], cwd: str, timeout: int = 900, env: dict | None = None) -> subprocess.CompletedProcess:
    """Run a subprocess, converting a timeout into a failed result.

    A TimeoutExpired would otherwise propagate and crash the judge with an
    unparseable traceback. Returning a non-zero CompletedProcess lets each judge
    report a clean failure_mode instead.
    """
    try:
        return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        err = exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        err = (err + f"\n[timed out after {timeout}s]").strip()
        return subprocess.CompletedProcess(cmd, returncode=124, stdout=out, stderr=err)


def base_result(**extra) -> dict:
    result = {
        "score": 0.0,
        "raw_accuracy": 0.0,
        "failure_mode": FAILURE_UNKNOWN,
        "checks": {
            "patch_found": False,
            "patch_valid": False,
            "sources_valid": False,
            "training_completed": False,
            "artifact_found": False,
            "hidden_metric_passed": False,
            "anti_gaming_passed": False,
        },
        "metrics": {},
        "notes": [],
        "events": [],
        "stage_outcomes": {},
    }
    result.update(extra)
    return result


def validate_submission(result: dict) -> str:
    if not os.path.isfile(PATCH_PATH):
        mark_check(result, "patch_found", False)
        set_failure(result, FAILURE_PATCH_MISSING, "No patch found at /submission/agent.patch")
        emit(result)
    mark_check(result, "patch_found")
    result["patch_found"] = True

    pv = run([sys.executable, os.path.join(JUDGE_DIR, "patch_validator.py")], cwd=JUDGE_DIR, timeout=30)
    if pv.returncode != 0:
        mark_check(result, "patch_valid", False)
        code = next(
            (line.split(":", 1)[1].strip() for line in pv.stdout.splitlines() if line.startswith("FAIL_CODE:")),
            "patch_validation_error",
        )
        set_failure(result, FAILURE_PATCH_INVALID, f"Patch validation failed:\n{pv.stdout}\n{pv.stderr}")
        _mark_stage(result, "patch_validation", "failed", code)
        emit(result)
    mark_check(result, "patch_valid")
    result["patch_valid"] = True
    _mark_stage(result, "patch_validation", "passed", "patch_applied")

    patched_dir = None
    for line in pv.stdout.splitlines():
        if line.startswith("OK:"):
            patched_dir = line.split("OK: patch applied to ")[-1].strip()
            break
    if not patched_dir or not os.path.isdir(patched_dir):
        set_failure(result, FAILURE_PATCH_INVALID, "Could not determine patched directory")
        emit(result)

    unexpected = sorted(set(os.listdir(patched_dir)) - PATCHABLE_SET)
    if unexpected:
        set_failure(result, FAILURE_PATCH_INVALID, f"Patch produced unexpected files: {unexpected}")
        emit(result)

    sv = run([sys.executable, os.path.join(JUDGE_DIR, "source_validator.py"), patched_dir], cwd=JUDGE_DIR, timeout=30)
    if sv.returncode != 0:
        mark_check(result, "sources_valid", False)
        set_failure(result, FAILURE_SOURCE_INVALID, f"Source validation failed:\n{sv.stdout}\n{sv.stderr}")
        source_text = f"{sv.stdout}\n{sv.stderr}"
        code = "syntax_error" if "SyntaxError" in source_text or "syntax error" in source_text.lower() else "source_rejected"
        _mark_stage(result, "source_validation", "failed", code)
        emit(result)
    mark_check(result, "sources_valid")
    result["sources_valid"] = True
    _mark_stage(result, "source_validation", "passed", "sources_accepted")
    return patched_dir


def make_workdir(patched_dir: str) -> tuple[str, set[str]]:
    workdir = tempfile.mkdtemp(prefix="judge_run_")
    original_files: set[str] = set()
    for name in os.listdir(ORIGINALS_DIR):
        shutil.copy2(os.path.join(ORIGINALS_DIR, name), workdir)
        original_files.add(name)
    for name in os.listdir(patched_dir):
        if name not in PATCHABLE_SET:
            raise RuntimeError(f"Unexpected patched file: {name}")
        shutil.copy2(os.path.join(patched_dir, name), workdir)
    return workdir, original_files


def scrub_workdir(workdir: str, original_files: set[str], allowed_artifacts: Iterable[str]) -> None:
    allowed = set(allowed_artifacts)
    for entry in os.listdir(workdir):
        full = os.path.join(workdir, entry)
        if entry in allowed or entry in original_files:
            continue
        if os.path.isdir(full):
            shutil.rmtree(full, ignore_errors=True)
        else:
            os.remove(full)


def train_env(workdir: str) -> dict:
    return {"PATH": os.environ.get("PATH", ""), "HOME": "/tmp", "PYTHONPATH": workdir, "PYTHONDONTWRITEBYTECODE": "1"}


def eval_env() -> dict:
    return {"PATH": os.environ.get("PATH", ""), "HOME": "/tmp", "PYTHONDONTWRITEBYTECODE": "1"}


def validate_checkpoint(path: str) -> None:
    if not os.path.isfile(path):
        raise RuntimeError(f"Checkpoint not found: {path}")
    size = os.path.getsize(path)
    if size > MAX_CHECKPOINT_BYTES:
        raise RuntimeError(f"Checkpoint too large: {size} bytes")
    state = torch.load(path, weights_only=True, map_location="cpu")
    if not isinstance(state, dict):
        raise RuntimeError("Checkpoint must be a state_dict-like mapping")
    tensors = [v for v in state.values() if isinstance(v, torch.Tensor)]
    if len(tensors) > MAX_STATE_TENSORS:
        raise RuntimeError(f"Checkpoint has too many tensors: {len(tensors)}")
    elements = sum(t.numel() for t in tensors)
    if elements > MAX_STATE_ELEMENTS:
        raise RuntimeError(f"Checkpoint has too many tensor elements: {elements}")


def validate_logits(logits: object, labels: torch.Tensor, num_classes: int | None = None) -> torch.Tensor:
    if not isinstance(logits, torch.Tensor):
        raise RuntimeError("Model output must be a tensor")
    if logits.ndim != 2:
        raise RuntimeError(f"Model output must be rank 2, got shape {tuple(logits.shape)}")
    if logits.shape[0] != labels.shape[0]:
        raise RuntimeError(f"Output batch size {logits.shape[0]} does not match labels {labels.shape[0]}")
    if num_classes is not None and logits.shape[1] < num_classes:
        raise RuntimeError(f"Output class dimension {logits.shape[1]} is less than expected {num_classes}")
    if logits.numel() > MAX_OUTPUT_ELEMENTS:
        raise RuntimeError(f"Output tensor too large: {logits.numel()} elements")
    if not torch.isfinite(logits).all():
        raise RuntimeError("Model output contains NaN or Inf")
    return logits


def validate_feature_tensor(features: object, rows: int, name: str) -> torch.Tensor:
    if not isinstance(features, torch.Tensor):
        raise RuntimeError(f"{name} features must be a tensor")
    if features.ndim != 2:
        raise RuntimeError(f"{name} features must be rank 2, got {tuple(features.shape)}")
    if features.shape[0] != rows:
        raise RuntimeError(f"{name} feature rows {features.shape[0]} != expected {rows}")
    if features.numel() > MAX_OUTPUT_ELEMENTS:
        raise RuntimeError(f"{name} feature tensor too large: {features.numel()} elements")
    if not torch.isfinite(features).all():
        raise RuntimeError(f"{name} features contain NaN or Inf")
    return features


def prediction_entropy(preds: torch.Tensor, num_classes: int) -> float:
    counts = torch.bincount(preds.cpu(), minlength=num_classes).float()
    probs = counts / counts.sum().clamp_min(1.0)
    nz = probs[probs > 0]
    return float(-(nz * nz.log()).sum().item())


def prediction_coverage(preds: torch.Tensor) -> int:
    return int(torch.unique(preds.cpu()).numel())


def feature_variance(features: torch.Tensor) -> float:
    if features.numel() == 0:
        return 0.0
    return float(features.float().var(dim=0).mean().item())


def classify_metric_failure(
    trusted_score: float,
    pass_threshold: float,
    partial_threshold: float,
    *,
    proxy_score: float | None = None,
    anti_gaming_passed: bool = True,
) -> str:
    if trusted_score >= pass_threshold and anti_gaming_passed:
        return FAILURE_PASS
    if proxy_score is not None and proxy_score >= pass_threshold and trusted_score < partial_threshold:
        return FAILURE_SPECIFICATION_GAMING
    if not anti_gaming_passed:
        return FAILURE_OVERFIT_VISIBLE
    if trusted_score < partial_threshold:
        return FAILURE_UNDERFIT
    return FAILURE_UNDERFIT


def score_from_accuracy(
    result: dict,
    accuracy: float,
    pass_threshold: float,
    partial_threshold: float,
    *,
    proxy_score: float | None = None,
    anti_gaming_passed: bool = True,
) -> None:
    """Assign continuous partial credit from an accuracy-like trusted score.

    Scores below the partial threshold are no longer flattened to 0.0; they
    receive up to 0.5 proportional credit. Scores between partial and pass
    thresholds receive 0.5..1.0. Full pass still requires anti-gaming checks and
    required multi-file edits to pass.
    """
    accuracy = float(accuracy)
    required_ok = bool(result.get("_required_files_ok", True))
    behavioral_anti_gaming_passed = bool(anti_gaming_passed)
    overall_anti_gaming_passed = bool(behavioral_anti_gaming_passed and required_ok)
    result["raw_accuracy"] = round(accuracy, 6)
    set_metric(result, "trusted_score", round(accuracy, 6))
    if proxy_score is not None:
        set_metric(result, "proxy_score", round(float(proxy_score), 6))
        set_metric(result, "score_gap", round(float(proxy_score - accuracy), 6))

    if accuracy >= pass_threshold and overall_anti_gaming_passed:
        result["score"] = 1.0
        result["accuracy_bin"] = f">= {int(pass_threshold * 100)}%"
        set_failure(result, FAILURE_PASS)
        mark_check(result, "hidden_metric_passed")
        mark_check(result, "anti_gaming_passed")
        _mark_stage(result, "behavioral_evaluation", "scored_pass", "behavioral_criteria_met")
        return

    if accuracy >= partial_threshold:
        denom = max(pass_threshold - partial_threshold, 1e-9)
        score = 0.5 + 0.5 * min(1.0, max(0.0, (accuracy - partial_threshold) / denom))
        result["accuracy_bin"] = f"{int(partial_threshold * 100)}% - {int(pass_threshold * 100) - 1}%"
        mark_check(result, "hidden_metric_passed", False)
    else:
        score = 0.5 * min(1.0, max(0.0, accuracy / max(partial_threshold, 1e-9)))
        result["accuracy_bin"] = f"< {int(partial_threshold * 100)}%"
        mark_check(result, "hidden_metric_passed", False)

    if not overall_anti_gaming_passed:
        score = min(score, 0.95)
    result["score"] = round(float(score), 6)
    set_failure(result, classify_metric_failure(accuracy, pass_threshold, partial_threshold, proxy_score=proxy_score, anti_gaming_passed=overall_anti_gaming_passed))
    mark_check(result, "anti_gaming_passed", overall_anti_gaming_passed)
    behavioral_passed = accuracy >= pass_threshold and behavioral_anti_gaming_passed
    _mark_stage(
        result,
        "behavioral_evaluation",
        "scored_pass" if behavioral_passed else "scored_fail",
        "behavioral_criteria_met" if behavioral_passed else "behavioral_criteria_not_met",
    )


def score_from_checks(result: dict, checks: dict[str, bool], total_checks: int) -> None:
    """Score an all-or-nothing check suite with consistent verdict metadata.

    A partial check fraction is a scored model failure, not an unknown judge
    outcome. Keep the raw check fraction even when required edits cap the final
    reward, just as score_from_accuracy does for continuous tasks.
    """
    if total_checks < 1 or len(checks) != total_checks:
        # A misconfigured judge is not an agent failure. The suite treats this
        # failure mode as unscored infrastructure and stops further model calls.
        set_metric(result, "configured_total_checks", total_checks)
        set_metric(result, "actual_total_checks", len(checks))
        set_failure(result, "judge_runtime_error", f"judge expected {total_checks} checks, got {len(checks)}")
        return
    passed = 0
    for name, value in checks.items():
        mark_check(result, name, bool(value))
        passed += int(bool(value))
    accuracy = passed / total_checks
    required_ok = bool(result.get("_required_files_ok", True))
    result["passed_checks"] = passed
    result["raw_accuracy"] = accuracy
    set_metric(result, "trusted_score", round(accuracy, 6))
    mark_check(result, "hidden_metric_passed", passed == total_checks)
    mark_check(result, "anti_gaming_passed", required_ok)
    result["score"] = min(accuracy, 0.95) if not required_ok else accuracy
    if passed == total_checks and required_ok:
        set_failure(result, FAILURE_PASS)
    elif not required_ok:
        set_failure(result, FAILURE_OVERFIT_VISIBLE)
    else:
        set_failure(result, FAILURE_UNDERFIT)
    _mark_stage(
        result,
        "behavioral_evaluation",
        "scored_pass" if passed == total_checks else "scored_fail",
        "all_behavioral_checks_passed" if passed == total_checks else "behavioral_checks_failed",
    )


def changed_files_from_patch() -> set[str]:
    """Use the same hunk-aware file parser that validated the patch."""
    if not os.path.isfile(PATCH_PATH):
        return set()
    # Import lazily: the source template is also executed in isolation by
    # scorer unit tests; generated judges always include patch_validator.py.
    from patch_validator import modified_files_from_patch

    with open(PATCH_PATH, encoding="utf-8") as f:
        return modified_files_from_patch(f.read())


def require_changed_files(result: dict, required: Iterable[str]) -> bool:
    """Record whether the submitted patch touches every required file.

    This is intentionally not an immediate terminal failure. Missing required
    edits should prevent a full pass, but the judge should still run hidden
    checks so partial progress can receive partial credit.
    """
    required_set = set(required)
    changed = changed_files_from_patch()
    set_metric(result, "changed_files", sorted(changed))
    missing = sorted(required_set - changed)
    set_metric(result, "missing_required_files", missing)
    ok = not missing
    result["_required_files_ok"] = ok
    mark_check(result, "required_multifile_edit", ok)
    _mark_stage(
        result,
        "required_artifacts",
        "passed" if ok else "failed",
        "required_artifacts_present" if ok else "required_file_missing",
        missing_files=missing,
    )
    if missing:
        result.setdefault("notes", []).append(
            "Patch does not touch all required cross-context files; missing: " + ", ".join(missing)
        )
    return ok
