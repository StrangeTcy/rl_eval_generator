"""Weak baseline: trust the claimed decoder."""


class BootstrapSolver:
    def solve(self, instance):
        return {"equivalent": True, "encodings": instance.get("encodings") or {}}
